import{z as e}from"./entry.ybbGp_Nr.js";function r(){const t=e();return{toast:t,notify_toast:(o,s,a)=>{t.add({severity:`${s}`,summary:"",detail:`${o}`,life:a||4e3})}}}export{r as t};
