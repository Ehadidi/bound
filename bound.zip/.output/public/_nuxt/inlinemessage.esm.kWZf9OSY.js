import{s as l}from"./index.esm.keNvxnAM.js";import{s as p,a as c}from"./index.esm.xv7THcOg.js";import{s as m}from"./index.esm.s_ACrGLG.js";import{s as u}from"./basecomponent.esm.YEHWBXPq.js";import{B as d}from"./entry.ybbGp_Nr.js";import{I as r,U as f,ai as o,J as v,D as i,P as g,V as y,X as $}from"./swiper-vue.--rts5zj.js";import"./baseicon.esm.QRi8nYIO.js";var h=`
@layer primevue {
    .p-inline-message {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        vertical-align: top;
    }
    
    .p-inline-message-icon {
        flex-shrink: 0;
    }

    .p-inline-message-icon-only .p-inline-message-text {
        visibility: hidden;
        width: 0;
    }

    .p-fluid .p-inline-message {
        display: flex;
    }
}
`,x={root:function(n){var s=n.props,t=n.instance;return["p-inline-message p-component p-inline-message-"+s.severity,{"p-inline-message-icon-only":!t.$slots.default}]},icon:function(n){var s=n.props;return["p-inline-message-icon",s.icon]},text:"p-inline-message-text"},B=d.extend({name:"inlinemessage",css:h,classes:x}),k={name:"BaseInlineMessage",extends:u,props:{severity:{type:String,default:"error"},icon:{type:String,default:void 0}},style:B,provide:function(){return{$parentInstance:this}}},I={name:"InlineMessage",extends:k,timeout:null,data:function(){return{visible:!0}},mounted:function(){var n=this;this.sticky||setTimeout(function(){n.visible=!1},this.life)},computed:{iconComponent:function(){return{info:p,success:l,warn:c,error:m}[this.severity]}}};function S(e,n,s,t,C,a){return r(),f("div",i({role:"alert","aria-live":"assertive","aria-atomic":"true",class:e.cx("root")},e.ptm("root")),[o(e.$slots,"icon",{},function(){return[(r(),v(g(e.icon?"span":a.iconComponent),i({class:e.cx("icon")},e.ptm("icon")),null,16,["class"]))]}),y("span",i({class:e.cx("text")},e.ptm("text")),[o(e.$slots,"default",{},function(){return[$(" ")]})],16)],16)}I.render=S;export{I as default};
