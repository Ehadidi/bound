import{B as r}from"./entry.ybbGp_Nr.js";import{s as e}from"./basecomponent.esm.YEHWBXPq.js";import{I as t,U as n,ai as s,D as o}from"./swiper-vue.--rts5zj.js";var p=`
@layer primevue {
    .p-avatar-group .p-avatar + .p-avatar {
        margin-left: -1rem;
    }

    .p-avatar-group {
        display: flex;
        align-items: center;
    }
}
`,i={root:"p-avatar-group p-component"},v=r.extend({name:"avatargroup",css:p,classes:i}),c={name:"BaseAvatarGroup",extends:e,style:v,provide:function(){return{$parentInstance:this}}},l={name:"AvatarGroup",extends:c};function m(a,u,d,f,g,$){return t(),n("div",o({class:a.cx("root")},a.ptm("root"),{"data-pc-name":"avatargroup"}),[s(a.$slots,"default")],16)}l.render=m;export{l as default};
